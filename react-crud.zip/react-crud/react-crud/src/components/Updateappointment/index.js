import Updateappointment from './Updateappointment';
export default Updateappointment;
		