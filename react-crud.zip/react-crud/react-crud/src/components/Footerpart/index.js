import Footerpart from './Footerpart';
export default Footerpart;
		